package com.example.votebms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5;
    Button b1;
    DBConnection db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        e1=(EditText)findViewById(R.id.name);
        e2=(EditText)findViewById(R.id.aadhar);
        e3=(EditText)findViewById(R.id.voter);
        e4=(EditText)findViewById(R.id.password);
        e5=(EditText)findViewById(R.id.cpass);
        b1=(Button)findViewById(R.id.button);
        db=new DBConnection(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertUser();
            }
        });
    }
    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }
    public void insertUser(){
        String name=e1.getText().toString();
        String a=e2.getText().toString();
        String v=e3.getText().toString();
        String p=e4.getText().toString();
        String cp=e5.getText().toString();
        if((!(name.equals(""))) && (!(a.equals(""))) && (!(v.equals(""))) && (!(p.equals(""))) && (!(cp.equals("")))){
            if(p.equals(cp)){
                Boolean ifexisting=db.checkUserinDB(a,v);
               if(ifexisting==false)
               {
                   boolean isNumericA = isNumeric(a);
                   boolean isNumericV = isNumeric(v);
                   int flag = 0;
                   if (isNumericA == false)
                   {
                       flag = flag + 1;
                       Toast.makeText(this, "Aadhar must be numeric", Toast.LENGTH_LONG).show();
                   }
                   if (a.length() < 12 || a.length() > 12)
                   {
                       Toast.makeText(this, "Exact 12 digits allowed in Aadhar number", Toast.LENGTH_LONG).show();
                       flag = 1;
                   }
                   if (isNumericV == false)
                   {
                       flag = flag + 1;
                       Toast.makeText(this, "VoterID must be numeric", Toast.LENGTH_LONG).show();
                   }
                   if (v.length() < 7 || v.length() > 7)
                   {
                       Toast.makeText(this, "Exact 7 digits allowed in voter id ", Toast.LENGTH_LONG).show();
                       flag = flag + 1;
                   }
                   if (flag == 0)
                   {
                       Boolean checkinsert = db.addUser(name, a, v, p);
                       if (checkinsert)
                       {
                           Toast.makeText(this, "You have been successfully registered!!", Toast.LENGTH_LONG).show();
                           Intent intent = new Intent(this, Login.class);
                           startActivity(intent);
                       }
                       else
                           {
                           Toast.makeText(this, "Sorry your aadhar and voter id are not valid or don't match!!", Toast.LENGTH_LONG).show();
                           }
                   }
//                   else
//                       {
//                       Toast.makeText(this, "You are already registered, go to Login!!", Toast.LENGTH_LONG).show();
//                       }
               }
               else
               {
                   Toast.makeText(this, "You are already registered, go to Login!!", Toast.LENGTH_LONG).show();
               }
            }
            else
                {
                Toast.makeText(this,"Passwords don't match!!",Toast.LENGTH_LONG).show();
                }
        }
        else
            {
            Toast.makeText(this,"All fields are required!!",Toast.LENGTH_LONG).show();
            }
    }
}