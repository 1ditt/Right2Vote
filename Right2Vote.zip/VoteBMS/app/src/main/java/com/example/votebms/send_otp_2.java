package com.example.votebms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class send_otp_2 extends AppCompatActivity {
  EditText editText;
  Button button;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String f = getIntent().getStringExtra("MyVoterID").toString();
        setContentView(R.layout.activity_send_otp2);
        button=findViewById(R.id.btnSend);
        editText=findViewById(R.id.etPhone);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editText.getText().toString().trim().isEmpty())
                {
                    Toast.makeText(getApplicationContext(), "Enter Mobile Number", Toast.LENGTH_SHORT).show();
                    return ;

                }
                else
                {
                    PhoneAuthProvider.getInstance().verifyPhoneNumber(
                            "+91"+editText.getText().toString(),
                            60,
                            TimeUnit.SECONDS,
                            send_otp_2.this,
                            new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                                @Override
                                public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                                }

                                @Override
                                public void onVerificationFailed(@NonNull FirebaseException e) {
                                    Toast.makeText(send_otp_2.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onCodeSent(@NonNull String s,@NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                    super.onCodeSent(s, forceResendingToken);
                                    Intent intent=new Intent(getApplicationContext(),verify_otp_2.class);
                                    intent.putExtra("MyVoterID",f);
                                    intent.putExtra("phone",editText.getText().toString());
                                    intent.putExtra("vid",s);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                    );
                }

            }
        });
    }
}
