package com.example.votebms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class verify_otp_2 extends AppCompatActivity {
Button button;
EditText e1,e2,e3,e4,e5,e6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String q = getIntent().getStringExtra("MyVoterID").toString();
//        String y = getIntent().getStringExtra("mobile").toString();
        setContentView(R.layout.activity_verify_otp2);
        button=findViewById(R.id.btnVerify);
        e1=findViewById(R.id.etC1);
        e2=findViewById(R.id.etC2);
        e3=findViewById(R.id.etC3);
        e4=findViewById(R.id.etC4);
        e5=findViewById(R.id.etC5);
        e6=findViewById(R.id.etC6);
        fill_OTP();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String v_id=getIntent().getStringExtra("vid");
                if(e1.getText().toString().trim().isEmpty()
                        ||e2.getText().toString().trim().isEmpty()
                        ||e3.getText().toString().trim().isEmpty()
                        ||e4.getText().toString().trim().isEmpty()
                        ||e5.getText().toString().trim().isEmpty()
                        ||e6.getText().toString().trim().isEmpty()
                ){
                    Toast.makeText(verify_otp_2.this,"Enter valid code",Toast.LENGTH_SHORT).show();
                    return;
                }
                String c=e1.getText().toString()+
                        e2.getText().toString()+
                        e3.getText().toString()+
                        e4.getText().toString()+
                        e5.getText().toString()+
                       e6.getText().toString();
                if (v_id!=null){
                    PhoneAuthCredential ph= PhoneAuthProvider.getCredential(
                            v_id,c
                    );
                    FirebaseAuth.getInstance().signInWithCredential(ph).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                Intent intent = new Intent(verify_otp_2.this, Home.class);
                                intent.putExtra("MyVoterID",q);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                                intent.putExtra("mobilePh",binding.mobile.getText().toString());
//                                intent.putExtra("mobilePh1",m);
                                startActivity(intent);

                            }
                            else{
                                Toast.makeText(getApplicationContext(),"Verification code was Invalid",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
    private void fill_OTP(){
        e1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    e2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        e2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    e3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        e3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    e4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
      e4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    e5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        e5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    e6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}